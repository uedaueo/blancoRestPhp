<?php
/*
 * バリューオブジェクトのサンプル。このクラスは単にサンプルです。実際の動作には利用されません。
 */
/*. DOC <@package blanco.sample.valueobject;>.*/

require_once('ObjectSample.php');
/*. require_module 'standard'; .*/;

/**
 * バリューオブジェクトのサンプル。このクラスは単にサンプルです。実際の動作には利用されません。
 */
class ObjectSample extends ObjectSample {
    /**
     * フィールド [stringField1]
     *
     * 項目の型 [string]
     * Override
     */
    private /*.string.*/ $fStringField1 = 'デフォルト';

    /**
     * フィールド [stringField3]
     *
     * 項目の型 [string]
     */
    private /*.string.*/ $fStringField3;

    /**
     * フィールド [stringField1]のセッターメソッド
     *
     * 項目の型 [string]
     * Override
     *
     * @param string $argStringField1 フィールド[stringField1]に格納したい値
     */
    public /*.void.*/ function setStringField1(/*.string.*/ $argStringField1) {
        /* パラメータの数、型チェックを行います。 */
        if (func_num_args() !== 1) {
            throw new Exception('[ArgumentException]: ObjectSample.setStringField1 のパラメータは[1]個である必要があります。しかし実際には[' . func_num_args() .  ']個のパラメータを伴って呼び出されました。');
        }
        if (gettype($argStringField1) !== 'string' && gettype($argStringField1) !== 'NULL') {
            throw new Exception('[ArgumentException]: ObjectSample.setStringField1 の1番目のパラメータは[string]型でなくてはなりません。しかし実際には[' . gettype($argStringField1) . ']型が与えられました。');
        }

        $this->fStringField1 = $argStringField1;
    }

    /**
     * フィールド[stringField1]のゲッターメソッド
     *
     * 項目の型 [string]
     * 規定値   [デフォルト]
     * Override
     *
     * @return string フィールド[stringField1]に格納されている値
     */
    public /*.string.*/ function getStringField1() {
        /* パラメータの数、型チェックを行います。 */
        if (func_num_args() !== 0) {
            throw new Exception('[ArgumentException]: ObjectSample.getStringField1 のパラメータは[0]個である必要があります。しかし実際には[' . func_num_args() .  ']個のパラメータを伴って呼び出されました。');
        }

        return $this->fStringField1;
    }

    /**
     * フィールド [stringField3]のセッターメソッド
     *
     * 項目の型 [string]
     *
     * @param string $argStringField3 フィールド[stringField3]に格納したい値
     */
    public /*.void.*/ function setStringField3(/*.string.*/ $argStringField3) {
        /* パラメータの数、型チェックを行います。 */
        if (func_num_args() !== 1) {
            throw new Exception('[ArgumentException]: ObjectSample.setStringField3 のパラメータは[1]個である必要があります。しかし実際には[' . func_num_args() .  ']個のパラメータを伴って呼び出されました。');
        }
        if (gettype($argStringField3) !== 'string' && gettype($argStringField3) !== 'NULL') {
            throw new Exception('[ArgumentException]: ObjectSample.setStringField3 の1番目のパラメータは[string]型でなくてはなりません。しかし実際には[' . gettype($argStringField3) . ']型が与えられました。');
        }

        $this->fStringField3 = $argStringField3;
    }

    /**
     * フィールド[stringField3]のゲッターメソッド
     *
     * 項目の型 [string]
     *
     * @return string フィールド[stringField3]に格納されている値
     */
    public /*.string.*/ function getStringField3() {
        /* パラメータの数、型チェックを行います。 */
        if (func_num_args() !== 0) {
            throw new Exception('[ArgumentException]: ObjectSample.getStringField3 のパラメータは[0]個である必要があります。しかし実際には[' . func_num_args() .  ']個のパラメータを伴って呼び出されました。');
        }

        return $this->fStringField3;
    }

    /**
     * このバリューオブジェクトの文字列表現を取得します。
     *
     * オブジェクトのシャロー範囲でしかtoStringされない点に注意して利用してください。
     *
     * @return string バリューオブジェクトの文字列表現。
     */
    public /*.string.*/ function __toString() {
        /* パラメータの数、型チェックを行います。 */
        if (func_num_args() !== 0) {
            throw new Exception('[ArgumentException]: ObjectSample.__toString のパラメータは[0]個である必要があります。しかし実際には[' . func_num_args() .  ']個のパラメータを伴って呼び出されました。');
        }

        $buf = '';
        $buf = $buf . 'blanco.sample.valueobject.ObjectSample[';
        $buf = $buf . 'stringField1=' . $this->fStringField1;
        $buf = $buf . ',stringField3=' . $this->fStringField3;
        $buf = $buf . ']';
        return $buf;
    }
}
?>
