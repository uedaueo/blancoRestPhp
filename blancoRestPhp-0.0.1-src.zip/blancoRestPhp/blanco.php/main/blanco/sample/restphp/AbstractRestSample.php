<?php
/*
 * blancoRestPhpのサンプルAPIです。
 */
/*. DOC <@package blanco.sample.restphp;>.*/

require_once('ApiBase.php');
require_once('RestSampleRequest.php');
require_once('RestSampleResponse.php');
/*. require_module 'standard'; .*/;

/**
 * blancoRestPhpのサンプルAPIです。
 */
abstract class AbstractRestSample extends ApiBase {
    /**
     * API実装クラスが実装すべき初期化メソッドです
     */
    protected abstract /*.void.*/ function initialize();

    /**
     * API実装クラスが実装すべき処理実行クラスです
     *
     * @param RestSampleRequest $argRestSampleRequest validation済みのリクエスト情報です
     * @return RestSampleResponse validation前のレスポンス情報です
     */
    protected abstract /*.RestSampleResponse.*/ function process(/*.RestSampleRequest.*/ $argRestSampleRequest);

    /**
     * APIベースクラスから呼ばれる実行メソッドです
     *
     * @param RestSampleRequest $argRestSampleRequest validation前のリクエスト情報です
     * @return RestSampleResponse validation済みのレスポンス情報です
     */
    protected /*.RestSampleResponse.*/ function execute(/*.RestSampleRequest.*/ $argRestSampleRequest) {
        /* パラメータの数、型チェックを行います。 */
        if (func_num_args() !== 1) {
            throw new Exception('[ArgumentException]: AbstractRestSample.execute のパラメータは[1]個である必要があります。しかし実際には[' . func_num_args() .  ']個のパラメータを伴って呼び出されました。');
        }
        if ($argRestSampleRequest instanceof RestSampleRequest === FALSE) {
            throw new Exception('[ArgumentException]: AbstractRestSample.execute の1番目のパラメータは[RestSampleRequest]型でなくてはなりません。しかし実際には[' . get_class($argRestSampleRequest) . ']型が与えられました。');
        }

        $retRestSampleResponse = $this->process( $argRestSampleRequest );


        return $retRestSampleResponse;
    }
}
?>
