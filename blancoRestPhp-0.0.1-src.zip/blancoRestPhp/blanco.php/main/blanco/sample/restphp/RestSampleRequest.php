<?php
/*
 * blancoRestPhpのサンプルAPIの要求電文です。
 */
/*. DOC <@package blanco.sample.restphp;>.*/

require_once('ObjectSample.php');
/*. require_module 'standard'; .*/;

/**
 * blancoRestPhpのサンプルAPIの要求電文です。
 */
class RestSampleRequest {
    /**
     * フィールド [field_1]
     *
     * 項目の型 [string]
     */
    private /*.string.*/ $fField1;

    /**
     * フィールド [field_2]
     *
     * 項目の型 [integer]
     */
    private /*.int.*/ $fField2;

    /**
     * フィールド [field_3]
     *
     * 項目の型 [boolean]
     */
    private /*.boolean.*/ $fField3;

    /**
     * フィールド [field_4]
     *
     * 項目の型 [float]
     */
    private /*.float.*/ $fField4;

    /**
     * フィールド [field_5]
     *
     * 項目の型 [array]
     */
    private /*.array.*/ $fField5;

    /**
     * フィールド [field_6]
     *
     * 項目の型 [object]
     */
    private /*.object.*/ $fField6;

    /**
     * フィールド [object_sample]
     *
     * 項目の型 [ObjectSample]
     */
    private /*.ObjectSample.*/ $fObjectSample;

    /**
     * フィールド [field_1]のセッターメソッド
     *
     * 項目の型 [string]
     *
     * @param string $argField1 フィールド[field_1]に格納したい値
     */
    public /*.void.*/ function setField1(/*.string.*/ $argField1) {
        /* パラメータの数、型チェックを行います。 */
        if (func_num_args() !== 1) {
            throw new Exception('[ArgumentException]: RestSampleRequest.setField1 のパラメータは[1]個である必要があります。しかし実際には[' . func_num_args() .  ']個のパラメータを伴って呼び出されました。');
        }
        if (gettype($argField1) !== 'string' && gettype($argField1) !== 'NULL') {
            throw new Exception('[ArgumentException]: RestSampleRequest.setField1 の1番目のパラメータは[string]型でなくてはなりません。しかし実際には[' . gettype($argField1) . ']型が与えられました。');
        }

        $this->fField1 = $argField1;
    }

    /**
     * フィールド[field_1]のゲッターメソッド
     *
     * 項目の型 [string]
     *
     * @return string フィールド[field_1]に格納されている値
     */
    public /*.string.*/ function getField1() {
        /* パラメータの数、型チェックを行います。 */
        if (func_num_args() !== 0) {
            throw new Exception('[ArgumentException]: RestSampleRequest.getField1 のパラメータは[0]個である必要があります。しかし実際には[' . func_num_args() .  ']個のパラメータを伴って呼び出されました。');
        }

        return $this->fField1;
    }

    /**
     * フィールド [field_2]のセッターメソッド
     *
     * 項目の型 [integer]
     *
     * @param integer $argField2 フィールド[field_2]に格納したい値
     */
    public /*.void.*/ function setField2(/*.int.*/ $argField2) {
        /* パラメータの数、型チェックを行います。 */
        if (func_num_args() !== 1) {
            throw new Exception('[ArgumentException]: RestSampleRequest.setField2 のパラメータは[1]個である必要があります。しかし実際には[' . func_num_args() .  ']個のパラメータを伴って呼び出されました。');
        }
        if (gettype($argField2) !== 'integer' && gettype($argField2) !== 'NULL') {
            throw new Exception('[ArgumentException]: RestSampleRequest.setField2 の1番目のパラメータは[integer]型でなくてはなりません。しかし実際には[' . gettype($argField2) . ']型が与えられました。');
        }

        $this->fField2 = $argField2;
    }

    /**
     * フィールド[field_2]のゲッターメソッド
     *
     * 項目の型 [integer]
     *
     * @return integer フィールド[field_2]に格納されている値
     */
    public /*.int.*/ function getField2() {
        /* パラメータの数、型チェックを行います。 */
        if (func_num_args() !== 0) {
            throw new Exception('[ArgumentException]: RestSampleRequest.getField2 のパラメータは[0]個である必要があります。しかし実際には[' . func_num_args() .  ']個のパラメータを伴って呼び出されました。');
        }

        return $this->fField2;
    }

    /**
     * フィールド [field_3]のセッターメソッド
     *
     * 項目の型 [boolean]
     *
     * @param boolean $argField3 フィールド[field_3]に格納したい値
     */
    public /*.void.*/ function setField3(/*.boolean.*/ $argField3) {
        /* パラメータの数、型チェックを行います。 */
        if (func_num_args() !== 1) {
            throw new Exception('[ArgumentException]: RestSampleRequest.setField3 のパラメータは[1]個である必要があります。しかし実際には[' . func_num_args() .  ']個のパラメータを伴って呼び出されました。');
        }
        if (gettype($argField3) !== 'boolean' && gettype($argField3) !== 'NULL') {
            throw new Exception('[ArgumentException]: RestSampleRequest.setField3 の1番目のパラメータは[boolean]型でなくてはなりません。しかし実際には[' . gettype($argField3) . ']型が与えられました。');
        }

        $this->fField3 = $argField3;
    }

    /**
     * フィールド[field_3]のゲッターメソッド
     *
     * 項目の型 [boolean]
     *
     * @return boolean フィールド[field_3]に格納されている値
     */
    public /*.boolean.*/ function getField3() {
        /* パラメータの数、型チェックを行います。 */
        if (func_num_args() !== 0) {
            throw new Exception('[ArgumentException]: RestSampleRequest.getField3 のパラメータは[0]個である必要があります。しかし実際には[' . func_num_args() .  ']個のパラメータを伴って呼び出されました。');
        }

        return $this->fField3;
    }

    /**
     * フィールド [field_4]のセッターメソッド
     *
     * 項目の型 [float]
     *
     * @param float $argField4 フィールド[field_4]に格納したい値
     */
    public /*.void.*/ function setField4(/*.float.*/ $argField4) {
        /* パラメータの数、型チェックを行います。 */
        if (func_num_args() !== 1) {
            throw new Exception('[ArgumentException]: RestSampleRequest.setField4 のパラメータは[1]個である必要があります。しかし実際には[' . func_num_args() .  ']個のパラメータを伴って呼び出されました。');
        }
        if (gettype($argField4) !== 'double' && gettype($argField4) !== 'NULL') {
            throw new Exception('[ArgumentException]: RestSampleRequest.setField4 の1番目のパラメータは[float]型でなくてはなりません。しかし実際には[' . gettype($argField4) . ']型が与えられました。');
        }

        $this->fField4 = $argField4;
    }

    /**
     * フィールド[field_4]のゲッターメソッド
     *
     * 項目の型 [float]
     *
     * @return float フィールド[field_4]に格納されている値
     */
    public /*.float.*/ function getField4() {
        /* パラメータの数、型チェックを行います。 */
        if (func_num_args() !== 0) {
            throw new Exception('[ArgumentException]: RestSampleRequest.getField4 のパラメータは[0]個である必要があります。しかし実際には[' . func_num_args() .  ']個のパラメータを伴って呼び出されました。');
        }

        return $this->fField4;
    }

    /**
     * フィールド [field_5]のセッターメソッド
     *
     * 項目の型 [array]
     *
     * @param array $argField5 フィールド[field_5]に格納したい値
     */
    public /*.void.*/ function setField5(/*.array.*/ $argField5) {
        /* パラメータの数、型チェックを行います。 */
        if (func_num_args() !== 1) {
            throw new Exception('[ArgumentException]: RestSampleRequest.setField5 のパラメータは[1]個である必要があります。しかし実際には[' . func_num_args() .  ']個のパラメータを伴って呼び出されました。');
        }
        if (gettype($argField5) !== 'array' && gettype($argField5) !== 'NULL') {
            throw new Exception('[ArgumentException]: RestSampleRequest.setField5 の1番目のパラメータは[array]型でなくてはなりません。しかし実際には[' . gettype($argField5) . ']型が与えられました。');
        }

        $this->fField5 = $argField5;
    }

    /**
     * フィールド[field_5]のゲッターメソッド
     *
     * 項目の型 [array]
     *
     * @return array フィールド[field_5]に格納されている値
     */
    public /*.array.*/ function getField5() {
        /* パラメータの数、型チェックを行います。 */
        if (func_num_args() !== 0) {
            throw new Exception('[ArgumentException]: RestSampleRequest.getField5 のパラメータは[0]個である必要があります。しかし実際には[' . func_num_args() .  ']個のパラメータを伴って呼び出されました。');
        }

        return $this->fField5;
    }

    /**
     * フィールド [field_6]のセッターメソッド
     *
     * 項目の型 [object]
     *
     * @param object $argField6 フィールド[field_6]に格納したい値
     */
    public /*.void.*/ function setField6(/*.object.*/ $argField6) {
        /* パラメータの数、型チェックを行います。 */
        if (func_num_args() !== 1) {
            throw new Exception('[ArgumentException]: RestSampleRequest.setField6 のパラメータは[1]個である必要があります。しかし実際には[' . func_num_args() .  ']個のパラメータを伴って呼び出されました。');
        }
        if (gettype($argField6) !== 'object' && gettype($argField6) !== 'NULL') {
            throw new Exception('[ArgumentException]: RestSampleRequest.setField6 の1番目のパラメータは[object]型でなくてはなりません。しかし実際には[' . gettype($argField6) . ']型が与えられました。');
        }

        $this->fField6 = $argField6;
    }

    /**
     * フィールド[field_6]のゲッターメソッド
     *
     * 項目の型 [object]
     *
     * @return object フィールド[field_6]に格納されている値
     */
    public /*.object.*/ function getField6() {
        /* パラメータの数、型チェックを行います。 */
        if (func_num_args() !== 0) {
            throw new Exception('[ArgumentException]: RestSampleRequest.getField6 のパラメータは[0]個である必要があります。しかし実際には[' . func_num_args() .  ']個のパラメータを伴って呼び出されました。');
        }

        return $this->fField6;
    }

    /**
     * フィールド [object_sample]のセッターメソッド
     *
     * 項目の型 [ObjectSample]
     *
     * @param ObjectSample $argObjectSample フィールド[object_sample]に格納したい値
     */
    public /*.void.*/ function setObjectSample(/*.ObjectSample.*/ $argObjectSample) {
        /* パラメータの数、型チェックを行います。 */
        if (func_num_args() !== 1) {
            throw new Exception('[ArgumentException]: RestSampleRequest.setObjectSample のパラメータは[1]個である必要があります。しかし実際には[' . func_num_args() .  ']個のパラメータを伴って呼び出されました。');
        }
        if ($argObjectSample instanceof ObjectSample === FALSE) {
            throw new Exception('[ArgumentException]: RestSampleRequest.setObjectSample の1番目のパラメータは[ObjectSample]型でなくてはなりません。しかし実際には[' . get_class($argObjectSample) . ']型が与えられました。');
        }

        $this->fObjectSample = $argObjectSample;
    }

    /**
     * フィールド[object_sample]のゲッターメソッド
     *
     * 項目の型 [ObjectSample]
     *
     * @return ObjectSample フィールド[object_sample]に格納されている値
     */
    public /*.ObjectSample.*/ function getObjectSample() {
        /* パラメータの数、型チェックを行います。 */
        if (func_num_args() !== 0) {
            throw new Exception('[ArgumentException]: RestSampleRequest.getObjectSample のパラメータは[0]個である必要があります。しかし実際には[' . func_num_args() .  ']個のパラメータを伴って呼び出されました。');
        }

        return $this->fObjectSample;
    }

    /**
     * このバリューオブジェクトの文字列表現を取得します。
     *
     * オブジェクトのシャロー範囲でしかtoStringされない点に注意して利用してください。
     *
     * @return string バリューオブジェクトの文字列表現。
     */
    public /*.string.*/ function __toString() {
        /* パラメータの数、型チェックを行います。 */
        if (func_num_args() !== 0) {
            throw new Exception('[ArgumentException]: RestSampleRequest.__toString のパラメータは[0]個である必要があります。しかし実際には[' . func_num_args() .  ']個のパラメータを伴って呼び出されました。');
        }

        $buf = '';
        $buf = $buf . 'blanco.sample.restphp.RestSampleRequest[';
        $buf = $buf . 'field_1=' . $this->fField1;
        $buf = $buf . ',field_2=' . (string) $this->fField2;
        $buf = $buf . ',field_3=' . ($this->fField3 ? 'true' : 'false');
        $buf = $buf . ',field_4=' . (string) $this->fField4;
        // TODO 配列は未対応です。
        $buf = $buf . ',field_6=' . (string) $this->fField6;
        $buf = $buf . ',object_sample=' . (string) $this->fObjectSample;
        $buf = $buf . ']';
        return $buf;
    }
}
?>
