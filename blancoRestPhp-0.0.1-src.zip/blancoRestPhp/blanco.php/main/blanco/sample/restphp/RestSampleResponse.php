<?php
/*
 * blancoRestPhpのサンプルAPIの応答電文です。
 */
/*. DOC <@package blanco.sample.restphp;>.*/

require_once('ObjectSample.php');
/*. require_module 'standard'; .*/;

/**
 * blancoRestPhpのサンプルAPIの応答電文です。
 */
class RestSampleResponse {
    /**
     * フィールド [result_field_1]
     *
     * 項目の型 [string]
     */
    private /*.string.*/ $fResultField1;

    /**
     * フィールド [result_field_2]
     *
     * 項目の型 [integer]
     */
    private /*.int.*/ $fResultField2;

    /**
     * フィールド [result_field_3]
     *
     * 項目の型 [boolean]
     */
    private /*.boolean.*/ $fResultField3;

    /**
     * フィールド [result_field_4]
     *
     * 項目の型 [float]
     */
    private /*.float.*/ $fResultField4;

    /**
     * フィールド [result_field_5]
     *
     * 項目の型 [array]
     */
    private /*.array.*/ $fResultField5;

    /**
     * フィールド [result_field_6]
     *
     * 項目の型 [object]
     */
    private /*.object.*/ $fResultField6;

    /**
     * フィールド [object_sample]
     *
     * 項目の型 [ObjectSample]
     */
    private /*.ObjectSample.*/ $fObjectSample;

    /**
     * フィールド [result_field_1]のセッターメソッド
     *
     * 項目の型 [string]
     *
     * @param string $argResultField1 フィールド[result_field_1]に格納したい値
     */
    public /*.void.*/ function setResultField1(/*.string.*/ $argResultField1) {
        /* パラメータの数、型チェックを行います。 */
        if (func_num_args() !== 1) {
            throw new Exception('[ArgumentException]: RestSampleResponse.setResultField1 のパラメータは[1]個である必要があります。しかし実際には[' . func_num_args() .  ']個のパラメータを伴って呼び出されました。');
        }
        if (gettype($argResultField1) !== 'string' && gettype($argResultField1) !== 'NULL') {
            throw new Exception('[ArgumentException]: RestSampleResponse.setResultField1 の1番目のパラメータは[string]型でなくてはなりません。しかし実際には[' . gettype($argResultField1) . ']型が与えられました。');
        }

        $this->fResultField1 = $argResultField1;
    }

    /**
     * フィールド[result_field_1]のゲッターメソッド
     *
     * 項目の型 [string]
     *
     * @return string フィールド[result_field_1]に格納されている値
     */
    public /*.string.*/ function getResultField1() {
        /* パラメータの数、型チェックを行います。 */
        if (func_num_args() !== 0) {
            throw new Exception('[ArgumentException]: RestSampleResponse.getResultField1 のパラメータは[0]個である必要があります。しかし実際には[' . func_num_args() .  ']個のパラメータを伴って呼び出されました。');
        }

        return $this->fResultField1;
    }

    /**
     * フィールド [result_field_2]のセッターメソッド
     *
     * 項目の型 [integer]
     *
     * @param integer $argResultField2 フィールド[result_field_2]に格納したい値
     */
    public /*.void.*/ function setResultField2(/*.int.*/ $argResultField2) {
        /* パラメータの数、型チェックを行います。 */
        if (func_num_args() !== 1) {
            throw new Exception('[ArgumentException]: RestSampleResponse.setResultField2 のパラメータは[1]個である必要があります。しかし実際には[' . func_num_args() .  ']個のパラメータを伴って呼び出されました。');
        }
        if (gettype($argResultField2) !== 'integer' && gettype($argResultField2) !== 'NULL') {
            throw new Exception('[ArgumentException]: RestSampleResponse.setResultField2 の1番目のパラメータは[integer]型でなくてはなりません。しかし実際には[' . gettype($argResultField2) . ']型が与えられました。');
        }

        $this->fResultField2 = $argResultField2;
    }

    /**
     * フィールド[result_field_2]のゲッターメソッド
     *
     * 項目の型 [integer]
     *
     * @return integer フィールド[result_field_2]に格納されている値
     */
    public /*.int.*/ function getResultField2() {
        /* パラメータの数、型チェックを行います。 */
        if (func_num_args() !== 0) {
            throw new Exception('[ArgumentException]: RestSampleResponse.getResultField2 のパラメータは[0]個である必要があります。しかし実際には[' . func_num_args() .  ']個のパラメータを伴って呼び出されました。');
        }

        return $this->fResultField2;
    }

    /**
     * フィールド [result_field_3]のセッターメソッド
     *
     * 項目の型 [boolean]
     *
     * @param boolean $argResultField3 フィールド[result_field_3]に格納したい値
     */
    public /*.void.*/ function setResultField3(/*.boolean.*/ $argResultField3) {
        /* パラメータの数、型チェックを行います。 */
        if (func_num_args() !== 1) {
            throw new Exception('[ArgumentException]: RestSampleResponse.setResultField3 のパラメータは[1]個である必要があります。しかし実際には[' . func_num_args() .  ']個のパラメータを伴って呼び出されました。');
        }
        if (gettype($argResultField3) !== 'boolean' && gettype($argResultField3) !== 'NULL') {
            throw new Exception('[ArgumentException]: RestSampleResponse.setResultField3 の1番目のパラメータは[boolean]型でなくてはなりません。しかし実際には[' . gettype($argResultField3) . ']型が与えられました。');
        }

        $this->fResultField3 = $argResultField3;
    }

    /**
     * フィールド[result_field_3]のゲッターメソッド
     *
     * 項目の型 [boolean]
     *
     * @return boolean フィールド[result_field_3]に格納されている値
     */
    public /*.boolean.*/ function getResultField3() {
        /* パラメータの数、型チェックを行います。 */
        if (func_num_args() !== 0) {
            throw new Exception('[ArgumentException]: RestSampleResponse.getResultField3 のパラメータは[0]個である必要があります。しかし実際には[' . func_num_args() .  ']個のパラメータを伴って呼び出されました。');
        }

        return $this->fResultField3;
    }

    /**
     * フィールド [result_field_4]のセッターメソッド
     *
     * 項目の型 [float]
     *
     * @param float $argResultField4 フィールド[result_field_4]に格納したい値
     */
    public /*.void.*/ function setResultField4(/*.float.*/ $argResultField4) {
        /* パラメータの数、型チェックを行います。 */
        if (func_num_args() !== 1) {
            throw new Exception('[ArgumentException]: RestSampleResponse.setResultField4 のパラメータは[1]個である必要があります。しかし実際には[' . func_num_args() .  ']個のパラメータを伴って呼び出されました。');
        }
        if (gettype($argResultField4) !== 'double' && gettype($argResultField4) !== 'NULL') {
            throw new Exception('[ArgumentException]: RestSampleResponse.setResultField4 の1番目のパラメータは[float]型でなくてはなりません。しかし実際には[' . gettype($argResultField4) . ']型が与えられました。');
        }

        $this->fResultField4 = $argResultField4;
    }

    /**
     * フィールド[result_field_4]のゲッターメソッド
     *
     * 項目の型 [float]
     *
     * @return float フィールド[result_field_4]に格納されている値
     */
    public /*.float.*/ function getResultField4() {
        /* パラメータの数、型チェックを行います。 */
        if (func_num_args() !== 0) {
            throw new Exception('[ArgumentException]: RestSampleResponse.getResultField4 のパラメータは[0]個である必要があります。しかし実際には[' . func_num_args() .  ']個のパラメータを伴って呼び出されました。');
        }

        return $this->fResultField4;
    }

    /**
     * フィールド [result_field_5]のセッターメソッド
     *
     * 項目の型 [array]
     *
     * @param array $argResultField5 フィールド[result_field_5]に格納したい値
     */
    public /*.void.*/ function setResultField5(/*.array.*/ $argResultField5) {
        /* パラメータの数、型チェックを行います。 */
        if (func_num_args() !== 1) {
            throw new Exception('[ArgumentException]: RestSampleResponse.setResultField5 のパラメータは[1]個である必要があります。しかし実際には[' . func_num_args() .  ']個のパラメータを伴って呼び出されました。');
        }
        if (gettype($argResultField5) !== 'array' && gettype($argResultField5) !== 'NULL') {
            throw new Exception('[ArgumentException]: RestSampleResponse.setResultField5 の1番目のパラメータは[array]型でなくてはなりません。しかし実際には[' . gettype($argResultField5) . ']型が与えられました。');
        }

        $this->fResultField5 = $argResultField5;
    }

    /**
     * フィールド[result_field_5]のゲッターメソッド
     *
     * 項目の型 [array]
     *
     * @return array フィールド[result_field_5]に格納されている値
     */
    public /*.array.*/ function getResultField5() {
        /* パラメータの数、型チェックを行います。 */
        if (func_num_args() !== 0) {
            throw new Exception('[ArgumentException]: RestSampleResponse.getResultField5 のパラメータは[0]個である必要があります。しかし実際には[' . func_num_args() .  ']個のパラメータを伴って呼び出されました。');
        }

        return $this->fResultField5;
    }

    /**
     * フィールド [result_field_6]のセッターメソッド
     *
     * 項目の型 [object]
     *
     * @param object $argResultField6 フィールド[result_field_6]に格納したい値
     */
    public /*.void.*/ function setResultField6(/*.object.*/ $argResultField6) {
        /* パラメータの数、型チェックを行います。 */
        if (func_num_args() !== 1) {
            throw new Exception('[ArgumentException]: RestSampleResponse.setResultField6 のパラメータは[1]個である必要があります。しかし実際には[' . func_num_args() .  ']個のパラメータを伴って呼び出されました。');
        }
        if (gettype($argResultField6) !== 'object' && gettype($argResultField6) !== 'NULL') {
            throw new Exception('[ArgumentException]: RestSampleResponse.setResultField6 の1番目のパラメータは[object]型でなくてはなりません。しかし実際には[' . gettype($argResultField6) . ']型が与えられました。');
        }

        $this->fResultField6 = $argResultField6;
    }

    /**
     * フィールド[result_field_6]のゲッターメソッド
     *
     * 項目の型 [object]
     *
     * @return object フィールド[result_field_6]に格納されている値
     */
    public /*.object.*/ function getResultField6() {
        /* パラメータの数、型チェックを行います。 */
        if (func_num_args() !== 0) {
            throw new Exception('[ArgumentException]: RestSampleResponse.getResultField6 のパラメータは[0]個である必要があります。しかし実際には[' . func_num_args() .  ']個のパラメータを伴って呼び出されました。');
        }

        return $this->fResultField6;
    }

    /**
     * フィールド [object_sample]のセッターメソッド
     *
     * 項目の型 [ObjectSample]
     *
     * @param ObjectSample $argObjectSample フィールド[object_sample]に格納したい値
     */
    public /*.void.*/ function setObjectSample(/*.ObjectSample.*/ $argObjectSample) {
        /* パラメータの数、型チェックを行います。 */
        if (func_num_args() !== 1) {
            throw new Exception('[ArgumentException]: RestSampleResponse.setObjectSample のパラメータは[1]個である必要があります。しかし実際には[' . func_num_args() .  ']個のパラメータを伴って呼び出されました。');
        }
        if ($argObjectSample instanceof ObjectSample === FALSE) {
            throw new Exception('[ArgumentException]: RestSampleResponse.setObjectSample の1番目のパラメータは[ObjectSample]型でなくてはなりません。しかし実際には[' . get_class($argObjectSample) . ']型が与えられました。');
        }

        $this->fObjectSample = $argObjectSample;
    }

    /**
     * フィールド[object_sample]のゲッターメソッド
     *
     * 項目の型 [ObjectSample]
     *
     * @return ObjectSample フィールド[object_sample]に格納されている値
     */
    public /*.ObjectSample.*/ function getObjectSample() {
        /* パラメータの数、型チェックを行います。 */
        if (func_num_args() !== 0) {
            throw new Exception('[ArgumentException]: RestSampleResponse.getObjectSample のパラメータは[0]個である必要があります。しかし実際には[' . func_num_args() .  ']個のパラメータを伴って呼び出されました。');
        }

        return $this->fObjectSample;
    }

    /**
     * このバリューオブジェクトの文字列表現を取得します。
     *
     * オブジェクトのシャロー範囲でしかtoStringされない点に注意して利用してください。
     *
     * @return string バリューオブジェクトの文字列表現。
     */
    public /*.string.*/ function __toString() {
        /* パラメータの数、型チェックを行います。 */
        if (func_num_args() !== 0) {
            throw new Exception('[ArgumentException]: RestSampleResponse.__toString のパラメータは[0]個である必要があります。しかし実際には[' . func_num_args() .  ']個のパラメータを伴って呼び出されました。');
        }

        $buf = '';
        $buf = $buf . 'blanco.sample.restphp.RestSampleResponse[';
        $buf = $buf . 'result_field_1=' . $this->fResultField1;
        $buf = $buf . ',result_field_2=' . (string) $this->fResultField2;
        $buf = $buf . ',result_field_3=' . ($this->fResultField3 ? 'true' : 'false');
        $buf = $buf . ',result_field_4=' . (string) $this->fResultField4;
        // TODO 配列は未対応です。
        $buf = $buf . ',result_field_6=' . (string) $this->fResultField6;
        $buf = $buf . ',object_sample=' . (string) $this->fObjectSample;
        $buf = $buf . ']';
        return $buf;
    }
}
?>
