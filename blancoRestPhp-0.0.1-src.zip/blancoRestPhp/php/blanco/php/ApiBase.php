<?php
/**
 * Created by IntelliJ IDEA.
 * User: tueda
 * Date: 15/07/05
 * Time: 15:33
 */

namespace blanco\php;


class ApiBase
{

    URL_HOGEHOGE....

    validate($requestObj);

    return $error;

    $response = $this->execute($request);
}