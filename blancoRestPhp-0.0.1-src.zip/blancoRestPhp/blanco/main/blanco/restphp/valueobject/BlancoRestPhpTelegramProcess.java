/*
 * このソースコードは blanco Frameworkにより自動生成されました。
 */
package blanco.restphp.valueobject;

/**
 * BlancoRestPhpのなかで利用されるValueObjectです。
 */
public class BlancoRestPhpTelegramProcess {
    /**
     * 電文ID
     *
     * フィールド: [name]。
     */
    private String fName;

    /**
     * 説明
     *
     * フィールド: [description]。
     */
    private String fDescription;

    /**
     * 要求電文ID
     *
     * フィールド: [requestId]。
     */
    private String fRequestId;

    /**
     * 応答電文ID
     *
     * フィールド: [responseId]。
     */
    private String fResponseId;

    /**
     * WebサービスID
     *
     * フィールド: [serviceId]。
     */
    private String fServiceId;

    /**
     * 名前空間
     *
     * フィールド: [namespace]。
     */
    private String fNamespace;

    /**
     * パッケージ
     *
     * フィールド: [package]。
     */
    private String fPackage;

    /**
     * ロケーション
     *
     * フィールド: [location]。
     */
    private String fLocation;

    /**
     * フィールド [name] の値を設定します。
     *
     * フィールドの説明: [電文ID]。
     *
     * @param argName フィールド[name]に設定する値。
     */
    public void setName(final String argName) {
        fName = argName;
    }

    /**
     * フィールド [name] の値を取得します。
     *
     * フィールドの説明: [電文ID]。
     *
     * @return フィールド[name]から取得した値。
     */
    public String getName() {
        return fName;
    }

    /**
     * フィールド [description] の値を設定します。
     *
     * フィールドの説明: [説明]。
     *
     * @param argDescription フィールド[description]に設定する値。
     */
    public void setDescription(final String argDescription) {
        fDescription = argDescription;
    }

    /**
     * フィールド [description] の値を取得します。
     *
     * フィールドの説明: [説明]。
     *
     * @return フィールド[description]から取得した値。
     */
    public String getDescription() {
        return fDescription;
    }

    /**
     * フィールド [requestId] の値を設定します。
     *
     * フィールドの説明: [要求電文ID]。
     *
     * @param argRequestId フィールド[requestId]に設定する値。
     */
    public void setRequestId(final String argRequestId) {
        fRequestId = argRequestId;
    }

    /**
     * フィールド [requestId] の値を取得します。
     *
     * フィールドの説明: [要求電文ID]。
     *
     * @return フィールド[requestId]から取得した値。
     */
    public String getRequestId() {
        return fRequestId;
    }

    /**
     * フィールド [responseId] の値を設定します。
     *
     * フィールドの説明: [応答電文ID]。
     *
     * @param argResponseId フィールド[responseId]に設定する値。
     */
    public void setResponseId(final String argResponseId) {
        fResponseId = argResponseId;
    }

    /**
     * フィールド [responseId] の値を取得します。
     *
     * フィールドの説明: [応答電文ID]。
     *
     * @return フィールド[responseId]から取得した値。
     */
    public String getResponseId() {
        return fResponseId;
    }

    /**
     * フィールド [serviceId] の値を設定します。
     *
     * フィールドの説明: [WebサービスID]。
     *
     * @param argServiceId フィールド[serviceId]に設定する値。
     */
    public void setServiceId(final String argServiceId) {
        fServiceId = argServiceId;
    }

    /**
     * フィールド [serviceId] の値を取得します。
     *
     * フィールドの説明: [WebサービスID]。
     *
     * @return フィールド[serviceId]から取得した値。
     */
    public String getServiceId() {
        return fServiceId;
    }

    /**
     * フィールド [namespace] の値を設定します。
     *
     * フィールドの説明: [名前空間]。
     *
     * @param argNamespace フィールド[namespace]に設定する値。
     */
    public void setNamespace(final String argNamespace) {
        fNamespace = argNamespace;
    }

    /**
     * フィールド [namespace] の値を取得します。
     *
     * フィールドの説明: [名前空間]。
     *
     * @return フィールド[namespace]から取得した値。
     */
    public String getNamespace() {
        return fNamespace;
    }

    /**
     * フィールド [package] の値を設定します。
     *
     * フィールドの説明: [パッケージ]。
     *
     * @param argPackage フィールド[package]に設定する値。
     */
    public void setPackage(final String argPackage) {
        fPackage = argPackage;
    }

    /**
     * フィールド [package] の値を取得します。
     *
     * フィールドの説明: [パッケージ]。
     *
     * @return フィールド[package]から取得した値。
     */
    public String getPackage() {
        return fPackage;
    }

    /**
     * フィールド [location] の値を設定します。
     *
     * フィールドの説明: [ロケーション]。
     *
     * @param argLocation フィールド[location]に設定する値。
     */
    public void setLocation(final String argLocation) {
        fLocation = argLocation;
    }

    /**
     * フィールド [location] の値を取得します。
     *
     * フィールドの説明: [ロケーション]。
     *
     * @return フィールド[location]から取得した値。
     */
    public String getLocation() {
        return fLocation;
    }

    /**
     * このバリューオブジェクトの文字列表現を取得します。
     *
     * <P>使用上の注意</P>
     * <UL>
     * <LI>オブジェクトのシャロー範囲のみ文字列化の処理対象となります。
     * <LI>オブジェクトが循環参照している場合には、このメソッドは使わないでください。
     * </UL>
     *
     * @return バリューオブジェクトの文字列表現。
     */
    @Override
    public String toString() {
        final StringBuffer buf = new StringBuffer();
        buf.append("blanco.restphp.valueobject.BlancoRestPhpTelegramProcess[");
        buf.append("name=" + fName);
        buf.append(",description=" + fDescription);
        buf.append(",requestId=" + fRequestId);
        buf.append(",responseId=" + fResponseId);
        buf.append(",serviceId=" + fServiceId);
        buf.append(",namespace=" + fNamespace);
        buf.append(",package=" + fPackage);
        buf.append(",location=" + fLocation);
        buf.append("]");
        return buf.toString();
    }
}
